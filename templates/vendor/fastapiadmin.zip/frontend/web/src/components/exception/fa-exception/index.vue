<template>
  <div class="page-content border-0! bg-transparent! min-h-screen flex items-center justify-center">
    <div class="flex items-center justify-center max-md:block! max-md:text-center">
      <FaThemeSvg :src="data.imgUrl" size="100%" class="w-100!" />
      <div class="ml-15 w-75 max-md:mx-auto max-md:mt-10 max-md:w-full max-md:text-center">
        <p class="text-xl leading-7 text-g-600 max-md:text-lg">{{ data.desc }}</p>
        <ElButton type="primary" size="large" @click="backHome" v-ripple class="mt-5">
          {{ data.btnText }}
        </ElButton>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useCommon } from "@/hooks/core/useCommon";
import { useUserStore } from "@stores";

const router = useRouter();
const userStore = useUserStore();

interface ExceptionData {
  /** 标题 */
  title: string;
  /** 描述 */
  desc: string;
  /** 按钮文本 */
  btnText: string;
  /** 图片地址 */
  imgUrl: string;
}

withDefaults(
  defineProps<{
    data: ExceptionData;
  }>(),
  {}
);

const { homePath } = useCommon();

const backHome = () => {
  const targetHomePath = homePath.value || "/";

  if (!userStore.isLogin) {
    router.push({
      name: "Login",
      query: { redirect: targetHomePath },
    });
    return;
  }

  router.push(targetHomePath);
};
</script>
